const db = require('../index')
const Histories = db.histories

exports.checkin = (req, res) => {
  if(!req.body.location ||
    !req.body.date ||
    !req.body.time) {
      res.status(400).send({ message: "No empty content!" })
      return 
    }

    const histories = new Histories({
      location: req.body.location,
      date: req.body.date,
      time: req.body.time,
      userId: req.body.userId
    })

    histories.save(histories)
    .then(data => { res.send(data) })
    .catch(err => {
      res.status(500).send({ message: err.message || "Failed to check in! Please try again." })
    })
}

exports.getOwn = (req, res) => {
  Histories.find({ userId: req.params.id })
  .then(data => { res.send(data) })
  .catch(err => {
    res.status(500).send({ message: err.message || `Failed to get histories of user ${req.body.userId}` })
  })
}