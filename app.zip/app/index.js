const mongoose = require('mongoose');

mongoose.Promise = global.Promise;
const db = {};
db.mongoose = mongoose;
db.url = process.env.MONGODB_URI;
db.histories = require('./models/histories.model')(mongoose);

module.exports = db