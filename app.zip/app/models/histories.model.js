module.exports = mongoose => {
  var schema = mongoose.Schema({
    historyId: { type: Number, default: 0 },
    location: String,
    date: String,
    time: String, 
    userId: String
  }, { timestamps: true })

  const Histories = mongoose.model('histories', schema);
  return Histories
};
